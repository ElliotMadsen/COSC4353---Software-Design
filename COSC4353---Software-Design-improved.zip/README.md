-> install pdfmake through npm install pdfmake 
-> put report.html in public folder
-> fonts folder can be put directly into root directory (required for pdfmake)

