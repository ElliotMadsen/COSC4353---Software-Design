document.getElementById("adminLoginBtn").addEventListener("click", function () {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const errorMessage = document.getElementById("error-message");

  const adminEmail = "admin@company.com";
  const adminPassword = "admin123";

  if (email === adminEmail && password === adminPassword) {
      alert("Admin login successful!");
      window.location.href = "../Home-Page/index (4).html";
  } else {
      errorMessage.textContent = "Invalid admin credentials.";
  }
});
