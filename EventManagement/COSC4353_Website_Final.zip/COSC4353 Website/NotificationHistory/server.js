const app = require("./app");

const PORT = 3144;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
