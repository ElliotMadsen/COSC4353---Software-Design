const mongoose = require("mongoose");

const volunteerHistorySchema = new mongoose.Schema(
  {
    eventName: {
      type: String,
      required: true,
    },
    eventDate: {
      type: Date,
      required: true,
    },
    location: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const VolunteerHistory = mongoose.model(
  "VolunteerHistory",
  volunteerHistorySchema
);

module.exports = VolunteerHistory;
