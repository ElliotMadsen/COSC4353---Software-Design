const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const cors = require("cors");
const { stringify } = require('csv-stringify');
const PdfPrinter = require('pdfmake');
const path = require('path');

console.log("Server is starting...");

// PDF font configuration
const fonts = {
  Roboto: {
      normal: './fonts/Roboto-Regular.ttf',
      bold: './fonts/Roboto-Medium.ttf',
      italics: './fonts/Roboto-Italic.ttf',
      bolditalics: './fonts/Roboto-MediumItalic.ttf',
  },
};

const printer = new PdfPrinter(fonts);

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect("mongodb://0.0.0.0:27017/COSC4353-Database", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});


// login
const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

const UserModel = mongoose.model("users", UserSchema);

// user profile
const ProfileSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "users", unique: true },
  fullName: { type: String },
  address1: { type: String },
  address2: { type: String },
  city: { type: String },
  state: { type: String },
  skills: { type: [String] },
  preferences: { type: Object },
  availability: { type: [String] },
});

const ProfileModel = mongoose.model("update_profiles", ProfileSchema);

// events
const EventSchema = new mongoose.Schema({
  creatorId: { type: mongoose.Schema.Types.ObjectId, ref: "users" },
  name: { type: String, required: true },
  description: { type: String },
  location: { type: String },
  skills: { type: [String] },
  urgency: { type: String },
  date: { type: Date, required: true },
});

const EventModel = mongoose.model("create_event", EventSchema);

// vol match
const MatchSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "update_profiles", required: true }, 
  eventId: { type: mongoose.Schema.Types.ObjectId, ref: "create_event", required: true },
  matchedAt: {type: Date, default: Date.now },
  confirmed: { type: Boolean, default: false }
});

const MatchModel = mongoose.model("matches", MatchSchema);


// signup
app.post("/signup", async (req, res) => {
  try {
    const { email, password } = req.body;
    const existingUser = await UserModel.findOne({ email });

    if (existingUser) return res.status(400).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new UserModel({ email, password: hashedPassword });

    await newUser.save();
    res.status(201).json({ message: "User created successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error creating user" });
  }
});

// login
app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await UserModel.findOne({ email });
    if (!user) return res.status(400).json({ message: "Invalid email or password" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: "Invalid email or password" });

    res.status(200).json({ message: "Login successful", userId: user._id });
  } catch (error) {
    res.status(500).json({ message: "Error logging in" });
  }
});

// --- PROFILE ROUTES ---

// update profile
app.post("/updateprofile", async (req, res) => {
  try {
    const { userId, fullName, address1, address2, city, state, skills, preferences, availability } = req.body;

    const profile = await ProfileModel.findOneAndUpdate(
      { userId },
      { fullName, address1, address2, city, state, skills, preferences, availability },
      { new: true, upsert: true }
    );

    res.status(200).json({ message: "Profile updated successfully", profile });
  } catch (error) {
    res.status(500).json({ message: "Error updating profile" });
  }
});

// profile route
app.get("/getProfile/:userId", async (req, res) => {
  try {
    const profile = await ProfileModel.findOne({ userId: req.params.userId });
    if (!profile) return res.status(404).json({ message: "Profile not found" });

    res.json(profile);
  } catch (error) {
    res.status(500).json({ message: "Error fetching profile" });
  }
});

// event creation
app.post("/application", async (req, res) => {
  try {
    const { creatorId, name, description, location, skills, urgency, date } = req.body;

    const newEvent = new EventModel({ creatorId, name, description, location, skills, urgency, date });
    await newEvent.save();

    res.status(201).json({ message: "Event created successfully", event: newEvent });
  } catch (error) {
    res.status(500).json({ message: "Error creating event" });
  }
});

// all event routes
app.get("/getEvents", async (req, res) => {
  try {
    const events = await EventModel.find({});
    res.json(events);
  } catch (error) {
    res.status(500).json({ message: "Error fetching events" });
  }
});

// --- MATCHING ROUTES ---

// vol match to events
app.get("/match/:userId", async (req, res) => {
  try{
    const profile = await ProfileModel.findOne({ _id: req.params.userId});
    if (!profile || !profile.skills || !profile.availability) {
      return res.status(404).json({ message: "Profile or required fields missing" });
    }

    const normalizedAvailability = profile.availability.map(str => {
      const date = new Date(str);
      return date.toISOString().split('T')[0];
    });
    const events = await EventModel.find({ skills: { $in: profile.skills } });
    const matchedEvent = events.find(event => {
      const eventDate = new Date(event.date).toISOString().split('T')[0];
      return normalizedAvailability.includes(eventDate);
    });

    if (!matchedEvent) {
      return res.status(404).json({ message: "No matching event based on user profile"});
    }
    res.status(200).json({ event: matchedEvent });
  } catch (error) {
    console.error("Error matching volunteer:", error);
    res.status(500).json({ message: "Error matching volunteer"});
  }
});

// get volunteers
app.get("/volunteers", async (req, res) => {
  try {
    const volunteers = await ProfileModel.find({}, { _id: 1, fullName: 1, skills: 1 });
    res.status(200).json(volunteers);
  } catch (error) {
    console.error("Error fetching volunteers:", error);
    res.status(500).json({ message: "Error fetching volunteers" });
  }
});

// Create a match
app.post("/match", async (req, res) => {
  try {
    const {userId, eventId } = req.body;

    if (!userId || !eventId) {
      return res.status(400).json( { message: "Missing user or event id"});
    }
    const newMatch = new MatchModel({ userId, eventId });
    await newMatch.save();

    res.status(201).json({ message: "Match saved" });
  } catch (error){
    console.error("error saving match", error);
    res.status(500).json({ message: "Failed to save the match" });
  }
});

// --- REPORT ROUTES ---

// Volunteer participation report
app.get('/reports/volunteer-participation', async (req, res) => {
  try {
    const matches = await MatchModel.find({});
    const events = await EventModel.find({});
    const users = await ProfileModel.find({});

    const reportData = matches.map(match => {
      const volunteer = users.find(u => u._id.toString() === match.userId.toString());
      const event = events.find(e => e._id.toString() === match.eventId.toString());

      return {
        volunteerName: volunteer?.fullName || 'Unknown',
        skills: volunteer?.skills?.join(', ') || 'N/A',
        eventName: event?.name || 'Unknown',
        eventDate: event?.date ? new Date(event.date).toLocaleDateString() : 'N/A',
        confirmed: match.confirmed ? 'Yes' : 'No'
      };
    });

    const format = req.query.format || 'json';

    if (format === 'csv') {
      stringify(reportData, { header: true }, (err, output) => {
        if (err) return res.status(500).send('CSV error');
        res.header('Content-Type', 'text/csv');
        res.header('Content-Disposition', 'attachment; filename="volunteer_participation.csv"');
        res.send(output);
      });
    } else if (format === 'pdf') {
      const documentDefinition = {
        content: [
          { text: 'Volunteer Participation Report', style: 'header' },
          ...reportData.map(entry => ([
            { text: entry.volunteerName, style: 'subheader' },
            `Skills: ${entry.skills}`,
            `Event: ${entry.eventName}`,
            `Date: ${entry.eventDate}`,
            `Confirmed: ${entry.confirmed}`,
            '\n',
          ])),
        ],
        styles: {
          header: { fontSize: 18, bold: true },
          subheader: { fontSize: 14, bold: true, margin: [0, 10, 0, 5] },
        },
      };

      const pdfDoc = printer.createPdfKitDocument(documentDefinition);
      const chunks = [];
      pdfDoc.on('data', chunk => chunks.push(chunk));
      pdfDoc.on('end', () => {
        const result = Buffer.concat(chunks);
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename="volunteer_participation.pdf"');
        res.send(result);
      });
      pdfDoc.end();
    } else {
      res.json(reportData);
    }
  } catch (err) {
    console.error('Error generating report:', err);
    res.status(500).send('Error generating report');
  }
});

// Event assignments report
app.get('/reports/event-assignments', async (req, res) => {
  try {
    const matches = await MatchModel.find({});
    const events = await EventModel.find({});
    const users = await ProfileModel.find({});

    const eventMap = {};
    matches.forEach(match => {
      const event = events.find(e => e._id.toString() === match.eventId.toString());
      const user = users.find(u => u._id.toString() === match.userId.toString());

      if (!event || !user) return;

      if (!eventMap[event._id]) {
        eventMap[event._id] = {
          eventName: event.name,
          date: event.date,
          location: event.location,
          description: event.description,
          assignedVolunteers: []
        };
      }

      eventMap[event._id].assignedVolunteers.push({
        name: user.fullName,
        skills: user.skills?.join(', ') || 'N/A'
      });
    });

    const reportData = Object.values(eventMap);
    const format = req.query.format || 'json';

    if (format === 'csv') {
      const csvData = reportData.flatMap(event =>
        event.assignedVolunteers.map(volunteer => ({
          eventName: event.eventName,
          eventDate: new Date(event.date).toLocaleDateString(),
          eventLocation: event.location,
          volunteerName: volunteer.name,
          volunteerSkills: volunteer.skills
        }))
      );

      stringify(csvData, { header: true }, (err, output) => {
        if (err) return res.status(500).send('CSV error');
        res.header('Content-Type', 'text/csv');
        res.header('Content-Disposition', 'attachment; filename="event_assignments.csv"');
        res.send(output);
      });
    } else if (format === 'pdf') {
      const documentDefinition = {
        content: [
          { text: 'Event Assignment Report', style: 'header' },
          ...reportData.map(event => ([
            { text: event.eventName, style: 'subheader' },
            `Date: ${new Date(event.date).toLocaleDateString()}`,
            `Location: ${event.location}`,
            `Description: ${event.description}`,
            ...event.assignedVolunteers.map(v => `Volunteer: ${v.name} (Skills: ${v.skills})`),
            '\n',
          ])),
        ],
        styles: {
          header: { fontSize: 18, bold: true },
          subheader: { fontSize: 14, bold: true, margin: [0, 10, 0, 5] },
        },
      };

      const pdfDoc = printer.createPdfKitDocument(documentDefinition);
      const chunks = [];
      pdfDoc.on('data', chunk => chunks.push(chunk));
      pdfDoc.on('end', () => {
        const result = Buffer.concat(chunks);
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename="event_assignments.pdf"');
        res.send(result);
      });
      pdfDoc.end();
    } else {
      res.json(reportData);
    }
  } catch (err) {
    console.error('Error generating report:', err);
    res.status(500).send('Error generating report');
  }
});

// Start the server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

module.exports = app;